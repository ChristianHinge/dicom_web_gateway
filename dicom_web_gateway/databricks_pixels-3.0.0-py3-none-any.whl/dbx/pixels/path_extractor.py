import pyspark.sql.functions as f
import pyspark.sql.types as t
from pyspark.ml.pipeline import Transformer
from pyspark.sql import DataFrame

from dbx.pixels.utils import identify_type_udf


class PathExtractor(Transformer):
    # Day extractor inherit of property of Transformer
    def __init__(self, inputCol="path", tagsCol="tags", basePath="dbfs:/"):
        self.inputCol = inputCol  # the name of your columns
        self.basePath = basePath

    def this():
        # define an unique ID
        this(Identifiable.randomUID("PathExtractor"))

    def copy(extra):
        defaultCopy(extra)

    def check_input_type(self, schema):
        field = schema[self.inputCol]
        # assert that field is a datetype
        if field.dataType != t.StringType():
            raise Exception(
                "PathExtractor input type %s did not match input type StringType" % field.dataType
            )

    def _transform(self, df):
        self.check_input_type(df.schema)
        return self._transform_impl(df, self.basePath, self.inputCol)

    @staticmethod
    def _transform_impl(df: DataFrame, basePath: str, inputCol: str):
        """User overridable"""
        return (
            df.withColumn("relative_path", f.regexp_replace(inputCol, basePath + "(.*)$", r"$1"))
            .withColumn("local_path", f.regexp_replace(inputCol, r"^dbfs:(.*$)", r"/dbfs$1"))
            .withColumn(
                "local_path", f.regexp_replace("local_path", r"/dbfs/Volumes/(.*$)", r"/Volumes/$1")
            )
            .withColumn("extension", f.regexp_replace("relative_path", r".*\.(\w+)$", r"$1"))
            .withColumn("file_type", identify_type_udf("local_path"))
            .withColumn(
                "path_tags",
                f.split(
                    f.regexp_replace("relative_path", r"([0-9a-zA-Z]+)([\_\.\/\:])", r"$1,"), ","
                ),
            )
        )
